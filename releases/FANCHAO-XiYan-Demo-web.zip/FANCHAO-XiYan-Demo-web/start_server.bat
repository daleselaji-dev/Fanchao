@echo off
chcp 65001 >nul
echo 启动本地服务器 http://localhost:8080 ...
where python >nul 2>nul && (start http://localhost:8080 & python -m http.server 8080 & goto :eof)
where py >nul 2>nul && (start http://localhost:8080 & py -m http.server 8080 & goto :eof)
where npx >nul 2>nul && (start http://localhost:8080 & npx --yes http-server -p 8080 -c-1 . & goto :eof)
echo 未找到 python 或 node。请直接双击 index.html（通常可直接运行）。
pause
