#!/usr/bin/env bash
# 一键本地服务器（备用方案；通常直接双击 index.html 即可）
cd "$(dirname "$0")"
echo "http://localhost:8080"
(command -v xdg-open >/dev/null && xdg-open http://localhost:8080) || (command -v open >/dev/null && open http://localhost:8080) || true
if command -v python3 >/dev/null; then python3 -m http.server 8080
elif command -v python >/dev/null; then python -m http.server 8080
elif command -v npx >/dev/null; then npx --yes http-server -p 8080 -c-1 .
else echo "未找到 python 或 node。请直接双击 index.html。"; fi
